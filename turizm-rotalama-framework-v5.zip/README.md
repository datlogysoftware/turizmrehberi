# Türkiye Turizm Rehberi & Rotalama — Framework v3

Bu paket; OpenAPI → SDK/hook codegen, Fastify plugin’leri, DB migration’ları, ETL,
GeoServer otomasyonu, CI ve k6 testleriyle **çalışabilir** bir iskelet sunar.


## Komutlar
pnpm i
pnpm run codegen
pnpm run hooks:codegen
pnpm run sdk:semver-check

## Veritabanı Migrasyonları
psql $DATABASE_URL_PG -f infra/db/migrations/001_init_extensions_and_schemas.sql
psql $DATABASE_URL_PG -f infra/db/migrations/002_enums_lookups.sql
psql $DATABASE_URL_PG -f infra/db/migrations/003_core_tables.sql
psql $DATABASE_URL_PG -f infra/db/migrations/004_indexes_triggers_views.sql
psql $DATABASE_URL_PG -f infra/db/migrations/005_staging_and_etl.sql
psql $DATABASE_URL_PG -f infra/db/seeds/seeds.sql

## ETL
node scripts/etl/csv_to_staging.js data.csv
node scripts/etl/geojson_to_staging.js data.geojson
psql $DATABASE_URL_PG -c "CALL ops.apply_staging_places('turkiye-go')"

## GeoServer
node scripts/geoserver/publish_layers.js
node scripts/geoserver/geowebcache_purge.js tourism:places_public 28.5 36.0 33.0 41.0

## k6
BASE_URL=http://localhost:3000 k6 run tests/k6/places_list.js
BASE_URL=http://localhost:3000 k6 run tests/k6/routing.js


## Adapter’lar
- **PostGIS**: `packages/adapters/src/postgis.ts` (bbox, id ile sorgu)
- **OSRM**: `packages/adapters/src/osrm.ts` (walk/drive profilleri)

## API Rotaları
- `GET /places?bbox=minLon,minLat,maxLon,maxLat&category=...&open_now=true&limit=...`
- `GET /places/:id`
- `GET /routing?mode=walk&from=lon,lat&to=lon,lat`

## Yerel Çalıştırma
```bash
# Postgres + OSRM (harita verisini .data/osrm içine yerleştirmeniz gerekir)
docker compose up -d

# Migrations
export DATABASE_URL_PG=postgresql://postgres:postgres@localhost:5432/tourism
psql $DATABASE_URL_PG -f infra/db/migrations/001_init_extensions_and_schemas.sql
psql $DATABASE_URL_PG -f infra/db/migrations/002_enums_lookups.sql
psql $DATABASE_URL_PG -f infra/db/migrations/003_core_tables.sql
psql $DATABASE_URL_PG -f infra/db/migrations/004_indexes_triggers_views.sql
psql $DATABASE_URL_PG -f infra/db/migrations/005_staging_and_etl.sql
psql $DATABASE_URL_PG -f infra/db/seeds/seeds.sql

# API
cd apps/api && node --loader ts-node/esm src/app/server.ts
```

> Not: OSRM için `turkey-latest.osm.pbf`'yi indirip `.data/osrm` altında preprocess etmelisiniz (osrm-extract/osrm-partition/osrm-customize).



## Public Yayına Hazırlık (v5)
- **CORS**: `ALLOWED_ORIGINS` ile virgüllü whitelist veya `*` (varsayılan).
- **Security Headers**: `@fastify/helmet` etkin.
- **API Key (opsiyonel)**: `API_KEYS` ortam değişkenine **SHA256 hash**'leri (hex) verin.
  - Üretmek için: `echo -n "MY_KEY" | sha256sum`
  - Anahtar yoksa GET uçları public; **yazma** uçları API key ister.
- **Dağıtık Rate Limit**: Redis varsa otomatik kullanır (`REDIS_URL`), yoksa in-memory.
- **Doğrulama**: Zod ile istek parametreleri doğrulanır; hatalar 400 döner.
- **Log Redaction**: `authorization`, `x-api-key` ve cookie set’leri loglardan maskelenir.

Çalıştırma örneği:
```bash
export ALLOWED_ORIGINS=https://www.ornek.com,https://app.ornek.com
export API_KEYS=ab12...sha256hex,cd34...sha256hex
export REDIS_URL=redis://localhost:6379
```
