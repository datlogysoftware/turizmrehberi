import fp from 'fastify-plugin';
import type { FastifyInstance, FastifyRequest } from 'fastify';
import crypto from 'node:crypto';

/**
 * Simple API key verification.
 * - Accepts `x-api-key` header.
 * - Keys are provided via env `API_KEYS` as comma-separated SHA256 hashes (hex).
 * - If no keys configured, plugin allows all (public mode).
 */
function sha256(s: string){ return crypto.createHash('sha256').update(s).digest('hex'); }

declare module 'fastify' {
  interface FastifyInstance {
    apiKey: { verify: (req: FastifyRequest) => boolean }
  }
}

export default fp(async function apiKeyPlugin(f: FastifyInstance){
  const hashes = (process.env.API_KEYS || '').split(',').map(s => s.trim()).filter(Boolean);
  const enabled = hashes.length > 0;
  f.decorate('apiKey', {
    verify: (req: FastifyRequest) => {
      if (!enabled) return true;
      const key = req.headers['x-api-key'] as string | undefined;
      if (!key) return false;
      const h = sha256(key);
      return hashes.includes(h);
    }
  });
});
