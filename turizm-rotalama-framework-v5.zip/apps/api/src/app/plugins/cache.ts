import fp from 'fastify-plugin'; import type { FastifyInstance } from 'fastify';
type CacheAPI = { get:(k:string)=>Promise<string|null>; set:(k:string,v:string,ttl?:number)=>Promise<void>; del:(k:string)=>Promise<void>; };
declare module 'fastify' { interface FastifyInstance { cache: CacheAPI; } }
async function makeCache(url?:string): Promise<CacheAPI> {
  try { const { default: IORedis } = await import('ioredis'); const r = new IORedis(url);
    return { get:(k)=>r.get(k), set:async(k,v,ttl=300)=>{ await r.set(k,v,'EX',ttl); }, del:(k)=>r.del(k).then(()=>{}) }; }
  catch { const store = new Map<string,{v:string,exp?:number}>(); return {
    async get(k){ const it = store.get(k); if(!it) return null; if(it.exp && it.exp < Date.now()){ store.delete(k); return null; } return it.v; },
    async set(k,v,ttl=300){ store.set(k,{v,exp: Date.now()+ttl*1000}); }, async del(k){ store.delete(k); } }; }
}
export default fp(async function cachePlugin(f: FastifyInstance){ const api = await makeCache(process.env.REDIS_URL); f.decorate('cache', api); });
