import fp from 'fastify-plugin';
import type { FastifyInstance } from 'fastify';

/**
 * Distributed token bucket using cache plugin (Redis if REDIS_URL set, else memory).
 * Key: ip or apiKey
 */
export default fp(async function rateLimitPlugin(f: FastifyInstance, opts:{ max?: number, refillPerSec?: number } = {}){
  const max = opts.max ?? 120;
  const refillPerSec = opts.refillPerSec ?? 2;

  async function take(key: string){
    const now = Date.now();
    const raw = await f.cache.get(`rl:${key}`);
    let state = raw ? JSON.parse(raw) as { tokens:number, updatedAt:number } : { tokens: max, updatedAt: now };
    const elapsed = (now - state.updatedAt)/1000;
    state.tokens = Math.min(max, state.tokens + elapsed*refillPerSec);
    state.updatedAt = now;
    if (state.tokens < 1) {
      await f.cache.set(`rl:${key}`, JSON.stringify(state), 60);
      return false;
    }
    state.tokens -= 1;
    await f.cache.set(`rl:${key}`, JSON.stringify(state), 60);
    return true;
  }

  f.addHook('onRequest', async (req, reply) => {
    const apiKey = (req.headers['x-api-key'] as string|undefined);
    const k = apiKey ? `k:${apiKey}` : `ip:${req.ip||'unknown'}`;
    const ok = await take(k);
    if (!ok) {
      reply.code(429).send({ code: 'RATE_LIMIT', message: 'Too Many Requests' });
      return;
    }
  });
});
