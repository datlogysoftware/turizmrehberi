import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { PostgisPlacesRepo } from '../../../../packages/adapters/src/postgis';

const listSchema = z.object({
  bbox: z.string().regex(/^-?\d+(?:\.\d+)?,-?\d+(?:\.\d+)?,-?\d+(?:\.\d+)?,-?\d+(?:\.\d+)?$/),
  category: z.string().optional(),
  open_now: z.string().optional(),
  limit: z.coerce.number().int().min(1).max(500).optional()
});

export async function placesRoutes(f: FastifyInstance) {
  const repo = new PostgisPlacesRepo({ connectionString: process.env.DATABASE_URL_PG });

  f.get('/places', async (req, reply) => {
    const p = listSchema.safeParse(req.query);
    if (!p.success) return reply.code(400).send({ code:'BAD_REQUEST', message:'Invalid query', details: p.error.flatten() });
    const { bbox, category, open_now, limit } = p.data;
    const parts = bbox.split(',').map(Number);
    const data = await repo.findByBBox([parts[0],parts[1],parts[2],parts[3]], category, open_now === 'true', Number(limit)||100);
    return data;
  });

  f.get('/places/:id', async (req, reply) => {
    const id = String((req.params as any).id || '');
    if (!/^[0-9a-fA-F-]{16,}$/.test(id)) return reply.code(400).send({ code:'BAD_REQUEST', message:'Invalid id' });
    const p = await repo.findById(id);
    if (!p) return reply.code(404).send({ code:'NOT_FOUND', message:'Place not found' });
    return p;
  });
}
