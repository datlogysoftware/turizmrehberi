import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { OSRMService } from '../../../../packages/adapters/src/osrm';

const querySchema = z.object({
  mode: z.enum(['walk','drive','transit']),
  from: z.string().regex(/^-?\d+(?:\.\d+)?,-?\d+(?:\.\d+)?$/),
  to: z.string().regex(/^-?\d+(?:\.\d+)?,-?\d+(?:\.\d+)?$/)
});

export async function routingRoutes(f: FastifyInstance) {
  const svc = new OSRMService(process.env.OSRM_URL || 'http://localhost:5000');
  f.get('/routing', async (req, reply) => {
    const p = querySchema.safeParse(req.query);
    if (!p.success) return reply.code(400).send({ code:'BAD_REQUEST', message:'Invalid query', details: p.error.flatten() });
    const pf = (s:string)=>s.split(',').map(Number) as [number,number];
    const res = await svc.route({ mode: p.data.mode, from: pf(p.data.from), to: pf(p.data.to) });
    return res;
  });
}
