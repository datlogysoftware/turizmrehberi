import Fastify from 'fastify';
import cachePlugin from './plugins/cache';
import rateLimitPlugin from './plugins/rate-limit';
import rbacPlugin from './plugins/rbac';
import tracingPlugin from './plugins/tracing';

const f = Fastify({
  logger: {
    transport: undefined,
    level: 'info',
    redact: {
      paths: ['req.headers.authorization','req.headers.x-api-key','response.headers["set-cookie"]'],
      remove: true
    }
  }
});
await f.register(tracingPlugin);
await f.register(rateLimitPlugin, { max: 120, refillPerSec: 2 });
await f.register(cachePlugin);
await f.register(rbacPlugin);

f.get('/health/live', async () => ({ ok: true }));
f.get('/secure/publish', async (req, reply) => {
  const user = { id: 'u1', role: 'editor', perms: { layers: ['tourism.poi'] } };
  if (!f.authz.can({ user, action: 'publish', resource: { type: 'layer', id: 'tourism.poi' } })) {
    reply.code(403).send({ code: 'FORBIDDEN', message: 'Not allowed' }); return;
  }
  return { ok: true };
});

export default f;


import { placesRoutes } from './routes/places';
import { routingRoutes } from './routes/routing';

await f.register(async (f)=>placesRoutes(f));
await f.register(async (f)=>routingRoutes(f));

// start if invoked directly
if (require.main === module) {
  f.listen({ port: Number(process.env.PORT)||3000, host: '0.0.0.0' }).catch(err => { f.log.error(err); process.exit(1); });
}


import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import apiKeyPlugin from './plugins/apikey';

// Security headers
await f.register(helmet, { contentSecurityPolicy: false });

// CORS whitelist
const allowed = (process.env.ALLOWED_ORIGINS || '*').split(',').map(s=>s.trim());
await f.register(cors, {
  origin: (origin, cb) => {
    if (!origin || allowed.includes('*') || allowed.includes(origin)) cb(null, true);
    else cb(new Error('CORS'), false);
  },
  credentials: true,
  exposedHeaders: ['x-trace-id']
});

// API key (optional public mode)
await f.register(apiKeyPlugin);

// Per-route preHandler to enforce API key on write operations (examples)
f.addHook('preHandler', async (req, reply) => {
  if (['POST','PUT','PATCH','DELETE'].includes(req.method)) {
    if (!f.apiKey.verify(req)) return reply.code(401).send({ code:'UNAUTHORIZED', message:'Invalid API key' });
  }
});
