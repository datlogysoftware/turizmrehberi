CREATE TYPE admin.place_category AS ENUM
('museum','ruins','park','beach','gastronomy','market','accommodation','atm','other');
CREATE TYPE admin.surface AS ENUM ('paved','unpaved','cobblestone','boardwalk','sand','other');
CREATE TYPE admin.access_level AS ENUM ('unknown','partial','yes','no');