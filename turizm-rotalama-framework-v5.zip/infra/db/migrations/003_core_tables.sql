CREATE TABLE IF NOT EXISTS core.places (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  source_id TEXT,
  name_tr TEXT NOT NULL,
  name_en TEXT,
  category admin.place_category NOT NULL,
  description_tr TEXT,
  description_en TEXT,
  price_info JSONB,
  props JSONB NOT NULL DEFAULT '{}'::jsonb,
  geom geometry(Geometry, 4326) NOT NULL,
  centroid geometry(Point, 4326) GENERATED ALWAYS AS (ST_Centroid(geom)) STORED,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  data_version BIGINT NOT NULL DEFAULT 1,
  valid_from TIMESTAMPTZ NOT NULL DEFAULT now(),
  valid_to TIMESTAMPTZ,
  checksum TEXT,
  source TEXT,
  updated_by TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS core.place_hours (
  place_id UUID NOT NULL REFERENCES core.places(id) ON DELETE CASCADE,
  weekday SMALLINT NOT NULL CHECK (weekday BETWEEN 0 AND 6),
  open_at TIME,
  close_at TIME,
  tz TEXT NOT NULL DEFAULT 'Europe/Istanbul',
  UNIQUE (place_id, weekday)
);
CREATE TABLE IF NOT EXISTS core.accessibility (
  place_id UUID PRIMARY KEY REFERENCES core.places(id) ON DELETE CASCADE,
  wheelchair admin.access_level NOT NULL DEFAULT 'unknown',
  stroller admin.access_level NOT NULL DEFAULT 'unknown',
  audio_guide BOOLEAN,
  tactile_paths BOOLEAN,
  surface admin.surface,
  slope_pct NUMERIC(5,2),
  extras JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE TABLE IF NOT EXISTS core.place_media (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  place_id UUID NOT NULL REFERENCES core.places(id) ON DELETE CASCADE,
  kind TEXT CHECK (kind IN ('photo','video','audio')),
  url TEXT NOT NULL,
  alt_tr TEXT,
  alt_en TEXT,
  position INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS core.parking (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT,
  fee_policy JSONB,
  geom geometry(Point,4326) NOT NULL
);
CREATE TABLE IF NOT EXISTS core.transport_stops (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  geom geometry(Point,4326) NOT NULL
);
CREATE TABLE IF NOT EXISTS core.transport_routes (
  id TEXT PRIMARY KEY,
  mode TEXT NOT NULL,
  name TEXT,
  color TEXT
);