CREATE INDEX IF NOT EXISTS idx_places_geom_gist ON core.places USING GIST (geom);
CREATE INDEX IF NOT EXISTS idx_places_centroid_gist ON core.places USING GIST (centroid);
CREATE INDEX IF NOT EXISTS idx_places_name_trgm ON core.places USING GIN (name_tr gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_places_props_gin ON core.places USING GIN (props jsonb_path_ops);
CREATE INDEX IF NOT EXISTS idx_places_valid ON core.places (valid_from, COALESCE(valid_to, 'infinity'));
CREATE INDEX IF NOT EXISTS idx_places_version ON core.places (data_version);
CREATE INDEX IF NOT EXISTS idx_stops_geom_gist ON core.transport_stops USING GIST (geom);
CREATE OR REPLACE FUNCTION admin.touch_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at := now(); RETURN NEW; END $$;
DROP TRIGGER IF EXISTS trg_touch_places ON core.places;
CREATE TRIGGER trg_touch_places BEFORE UPDATE ON core.places FOR EACH ROW EXECUTE FUNCTION admin.touch_updated_at();
CREATE OR REPLACE FUNCTION api.is_open_now(p_id UUID, tz TEXT DEFAULT 'Europe/Istanbul') RETURNS BOOLEAN LANGUAGE sql AS $$
WITH now_local AS ( SELECT (now() AT TIME ZONE tz) AS ts ),
h AS ( SELECT * FROM core.place_hours WHERE place_id = p_id )
SELECT EXISTS ( SELECT 1 FROM now_local nl JOIN h ON h.weekday = EXTRACT(DOW FROM nl.ts)
  WHERE h.open_at IS NOT NULL AND (nl.ts::time BETWEEN h.open_at AND h.close_at) ); $$;
CREATE OR REPLACE VIEW api.places_public AS
SELECT p.id, p.name_tr, p.name_en, p.category, ST_AsGeoJSON(p.centroid)::jsonb AS geom_point,
  p.price_info, p.props, p.source, p.data_version, api.is_open_now(p.id) AS open_now
FROM core.places p WHERE p.is_active = TRUE AND p.valid_to IS NULL;
CREATE MATERIALIZED VIEW IF NOT EXISTS api.places_ranking AS
SELECT p.id, ( 0.35 * COALESCE((p.props->>'popularity')::numeric,0) + 0.25 * CASE WHEN api.is_open_now(p.id) THEN 1 ELSE 0 END
  + 0.20 * COALESCE((p.props->>'access_score')::numeric,0) + 0.20 * COALESCE((p.props->>'quality_score')::numeric,0) )::numeric(6,3) AS score
FROM core.places p WHERE p.is_active = TRUE AND p.valid_to IS NULL;
CREATE INDEX IF NOT EXISTS idx_places_ranking_score ON api.places_ranking(score DESC);