CREATE TABLE IF NOT EXISTS staging_public.places_raw (
  source_id TEXT, name_tr TEXT, name_en TEXT, category TEXT, price_info JSONB, props JSONB,
  geom_wkt TEXT, updated_at TIMESTAMPTZ, checksum TEXT );
CREATE OR REPLACE FUNCTION ops.upsert_place(_row JSONB, _source TEXT, _version BIGINT) RETURNS UUID LANGUAGE plpgsql AS $$
DECLARE _id UUID; BEGIN
  INSERT INTO core.places (id, source_id, name_tr, name_en, category, price_info, props, geom, source, data_version, checksum)
  VALUES (COALESCE((_row->>'id')::uuid, uuid_generate_v4()), _row->>'source_id', _row->>'name_tr', NULLIF(_row->>'name_en',''),
    (_row->>'category')::admin.place_category, COALESCE((_row->'price_info'), '{}'::jsonb), COALESCE((_row->'props'), '{}'::jsonb),
    ST_SetSRID(ST_GeomFromText(_row->>'geom_wkt'), 4326), _source, _version, _row->>'checksum')
  ON CONFLICT (id) DO UPDATE SET
    name_tr = EXCLUDED.name_tr, name_en = EXCLUDED.name_en, category = EXCLUDED.category, price_info = EXCLUDED.price_info,
    props = EXCLUDED.props, geom = EXCLUDED.geom, source = EXCLUDED.source,
    data_version = GREATEST(core.places.data_version, EXCLUDED.data_version) + 1,
    checksum = EXCLUDED.checksum, updated_by = current_user, updated_at = now()
  WHERE core.places.checksum IS DISTINCT FROM EXCLUDED.checksum RETURNING id INTO _id;
  RETURN _id; END $$;
CREATE OR REPLACE PROCEDURE ops.apply_staging_places(_source TEXT) LANGUAGE plpgsql AS $$
DECLARE r RECORD; _ver BIGINT := EXTRACT(EPOCH FROM now()); BEGIN
  FOR r IN SELECT * FROM staging_public.places_raw LOOP PERFORM ops.upsert_place(to_jsonb(r), _source, _ver); END LOOP; END $$;