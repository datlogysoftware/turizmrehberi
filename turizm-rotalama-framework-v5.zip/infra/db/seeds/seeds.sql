INSERT INTO core.places (name_tr, category, geom, source, props) VALUES
('Antalya Müzesi','museum', ST_SetSRID(ST_Point(30.6909,36.8864),4326), 'seed', '{"popularity":0.8,"quality_score":0.9}'),
('Aspendos Antik Tiyatrosu','ruins', ST_SetSRID(ST_Point(31.1725,36.9390),4326), 'seed', '{"popularity":0.7,"quality_score":0.95}');