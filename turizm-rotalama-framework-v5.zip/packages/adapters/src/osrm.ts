import type { RoutingService, RouteResponse, Mode } from '../../ports/src';

type Profile = 'foot'|'driving'|'bike';
function profileOf(mode: Mode): Profile {
  if (mode === 'walk') return 'foot';
  if (mode === 'drive') return 'driving';
  return 'foot'; // transit placeholder
}

export class OSRMService implements RoutingService {
  constructor(private baseUrl = 'http://localhost:5000') {}
  async route(params: { mode: Mode; from: [number,number]; to: [number,number] }): Promise<RouteResponse> {
    const profile = profileOf(params.mode);
    const url = `${this.baseUrl}/route/v1/${profile}/${params.from[0]},${params.from[1]};${params.to[0]},${params.to[1]}?overview=full&geometries=geojson`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`OSRM ${res.status}`);
    const j = await res.json();
    const r = j.routes?.[0];
    return {
      mode: params.mode,
      distance_m: Math.round(r.distance),
      duration_s: Math.round(r.duration),
      legs: r.legs?.map((l:any)=>({ distance_m: Math.round(l.distance), duration_s: Math.round(l.duration) })) ?? []
    };
  }
}
