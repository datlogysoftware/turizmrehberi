import { Client, ClientConfig } from 'pg';
import type { PlacesRepository, BBox, Place } from '../../ports/src';

export class PostgisPlacesRepo implements PlacesRepository {
  constructor(private cfg: ClientConfig) {}

  private async withClient<T>(fn:(c:Client)=>Promise<T>): Promise<T> {
    const c = new Client(this.cfg);
    await c.connect();
    try { return await fn(c); } finally { await c.end(); }
  }

  async findByBBox(bbox: BBox, category?: string, openNow?: boolean, limit=100): Promise<Place[]> {
    const [minLon,minLat,maxLon,maxLat] = bbox;
    const params:any[] = [minLon,minLat,maxLon,maxLat];
    let i=5;
    let where = "WHERE p.is_active = TRUE AND p.valid_to IS NULL";
    if (category) { where += ` AND p.category = $${i++}::admin.place_category`; params.push(category); }
    if (openNow) { where += " AND api.is_open_now(p.id) = true"; }
    const sql = `WITH env AS (SELECT ST_MakeEnvelope($1,$2,$3,$4,4326) AS bbox)
      SELECT p.id, p.name_tr, p.name_en, p.category,
             ST_X(p.centroid) AS lon, ST_Y(p.centroid) AS lat,
             p.price_info, p.props
      FROM core.places p, env e
      WHERE ST_Intersects(p.geom, e.bbox) AND p.is_active = TRUE AND p.valid_to IS NULL
        ${category ? ` AND p.category = $5::admin.place_category` : ''}
        ${openNow ? ` AND api.is_open_now(p.id) = true` : ''}
      ORDER BY (SELECT score FROM api.places_ranking r WHERE r.id = p.id) DESC NULLS LAST
      LIMIT ${limit};`;
    return this.withClient(async c => {
      const res = await c.query(sql, params);
      return res.rows.map(r => ({
        id: r.id, name_tr: r.name_tr, name_en: r.name_en, category: r.category,
        geom: { lon: Number(r.lon), lat: Number(r.lat) },
        price_info: r.price_info || undefined, props: r.props || undefined
      }));
    });
  }

  async findById(id: string): Promise<Place | null> {
    const sql = `SELECT p.id, p.name_tr, p.name_en, p.category,
                        ST_X(p.centroid) AS lon, ST_Y(p.centroid) AS lat,
                        p.price_info, p.props
                 FROM core.places p WHERE p.id = $1`;
    return this.withClient(async c => {
      const res = await c.query(sql, [id]);
      if (res.rowCount === 0) return null;
      const r = res.rows[0];
      return { id: r.id, name_tr: r.name_tr, name_en: r.name_en, category: r.category,
               geom: { lon: Number(r.lon), lat: Number(r.lat) },
               price_info: r.price_info || undefined, props: r.props || undefined };
    });
  }
}
