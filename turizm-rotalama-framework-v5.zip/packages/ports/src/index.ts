export type BBox = [number, number, number, number];

export interface Place {
  id: string; name_tr: string; name_en?: string; category: string;
  geom: { lon:number; lat:number };
  price_info?: { currency:string; amount:number };
  props?: any;
}

export interface PlacesRepository {
  findByBBox(bbox: BBox, category?: string, openNow?: boolean, limit?: number): Promise<Place[]>;
  findById(id: string): Promise<Place | null>;
}

export type Mode = 'walk'|'drive'|'transit';
export interface RouteResponse { mode: Mode; distance_m: number; duration_s: number; legs: Array<{ distance_m:number; duration_s:number; geometry?: any }>; }

export interface RoutingService {
  route(params: { mode: Mode; from: [number,number]; to: [number,number] }): Promise<RouteResponse>;
}
