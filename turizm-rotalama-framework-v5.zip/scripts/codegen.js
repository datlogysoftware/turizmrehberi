// OpenAPI -> TS types via openapi-typescript
import { execSync } from 'node:child_process';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
const spec = './openapi/openapi.yaml';
const out = './packages/sdk/src/types.generated.ts';
try {
  execSync(`npx openapi-typescript ${spec} -o ${out}`, { stdio: 'inherit' });
  console.log('✅ Generated', out);
} catch (e) {
  console.warn('⚠️ openapi-typescript not available; writing stub.');
  if (!existsSync(dirname(out))) mkdirSync(dirname(out), { recursive: true });
  writeFileSync(out, '// generation failed; use handcrafted types in types.ts\n');
}
