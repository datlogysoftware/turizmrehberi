// csv_to_staging.js
import fs from 'node:fs'; import { Client } from 'pg';
const [,, csvPath] = process.argv; if (!csvPath) { console.error('csv path required'); process.exit(1); }
const pg = new Client({ connectionString: process.env.DATABASE_URL_PG }); await pg.connect();
const lines = fs.readFileSync(csvPath,'utf-8').trim().split(/\r?\n/); const [header, ...rows] = lines;
for (const row of rows) {
  const [source_id,name_tr,name_en,category,lon,lat,price_info,props,updated_at,checksum] = row.split(',');
  const geom_wkt = `POINT(${lon} ${lat})`;
  await pg.query(`INSERT INTO staging_public.places_raw(source_id,name_tr,name_en,category,price_info,props,geom_wkt,updated_at,checksum)
                  VALUES($1,$2,$3,$4,$5::jsonb,$6::jsonb,$7,$8,$9) ON CONFLICT DO NOTHING`,
     [source_id,name_tr,name_en,category,price_info||'{}',props||'{}',geom_wkt,updated_at||new Date().toISOString(),checksum||null]);
}
console.log('CSV imported'); await pg.end();
