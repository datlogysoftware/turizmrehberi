// geojson_to_staging.js
import fs from 'node:fs'; import { Client } from 'pg';
const [,, gjPath] = process.argv; if (!gjPath) { console.error('geojson path required'); process.exit(1); }
const gj = JSON.parse(fs.readFileSync(gjPath,'utf-8'));
const pg = new Client({ connectionString: process.env.DATABASE_URL_PG }); await pg.connect();
for (const f of gj.features) {
  const p = f.properties || {}; const name_tr = p.name_tr || p.name || ''; const name_en = p.name_en || '';
  const category = (p.category || 'other').toLowerCase(); const price_info = JSON.stringify(p.price_info || {});
  const props = JSON.stringify(p.props || {}); const updated_at = p.updated_at || new Date().toISOString(); const checksum = p.checksum || null;
  const [lon,lat] = f.geometry.type === 'Point' ? f.geometry.coordinates : [0,0]; const geom_wkt = `POINT(${lon} ${lat})`;
  await pg.query(`INSERT INTO staging_public.places_raw(source_id,name_tr,name_en,category,price_info,props,geom_wkt,updated_at,checksum)
                  VALUES($1,$2,$3,$4,$5::jsonb,$6::jsonb,$7,$8,$9) ON CONFLICT DO NOTHING`,
     [p.source_id||null,name_tr,name_en,category,price_info,props,geom_wkt,updated_at,checksum]);
}
console.log('GeoJSON imported'); await pg.end();
