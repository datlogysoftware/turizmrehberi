// geowebcache_purge.js
import fetch from 'node-fetch';
const base = process.env.GEOSERVER_URL.replace(/\/$/,'') + '/gwc/rest';
const auth = 'Basic ' + Buffer.from(process.env.GEOSERVER_USER+':'+process.env.GEOSERVER_PASS).toString('base64');
async function purge(layer, bbox){
  const url = base + `/seed/${encodeURIComponent(layer)}.json`;
  const body = { "seedRequest": { "name": layer, "bounds": bbox ? {"coords":{"double":bbox}} : null, "type": "truncate", "gridSetId": "EPSG:4326", "zoomStart": 0, "zoomStop": 18, "format": "image/png" } };
  const res = await fetch(url, { method:'POST', headers:{ 'authorization':auth, 'content-type':'application/json' }, body: JSON.stringify(body) });
  if(!res.ok){ throw new Error(await res.text()); } console.log('Purge requested');
}
const [,, layer, minx, miny, maxx, maxy] = process.argv;
const bbox = (minx && miny && maxx && maxy) ? [minx, miny, maxx, maxy].map(Number) : null;
purge(layer || 'tourism:places_public', bbox).catch(e=>{ console.error(e); process.exit(1); });
