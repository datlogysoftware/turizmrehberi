// publish_layers.js
import fetch from 'node-fetch';
const env = (k, req=true) => { const v = process.env[k]; if (!v && req) throw new Error(`Missing env ${k}`); return v || ''; };
const base = env('GEOSERVER_URL').replace(/\/$/,'') + '/rest';
const auth = 'Basic ' + Buffer.from(env('GEOSERVER_USER')+':'+env('GEOSERVER_PASS')).toString('base64');
async function call(method, path, body, type='application/json'){
  const res = await fetch(base + path, { method, headers: { 'authorization': auth, 'content-type': type, 'accept':'application/json' },
    body: body ? (typeof body==='string'?body:JSON.stringify(body)) : undefined });
  if(!res.ok){ throw new Error(`${method} ${path} -> ${res.status}: ${await res.text()}`); } return res;
}
async function ensureWorkspace(ws){ await call('POST', `/workspaces`, { workspace:{ name: ws } }).catch(()=>{}); }
async function ensurePgStore(ws, store){
  const body = { dataStore: { name: store, connectionParameters: { entry: [
    {"@key":"host","$": env('PG_HOST')},{"@key":"port","$":"5432"},{"@key":"database","$": env('PG_DB')},
    {"@key":"user","$": env('PG_USER')},{"@key":"passwd","$": env('PG_PASS')},{"@key":"dbtype","$":"postgis"},
    {"@key":"schema","$":"api"},{"@key":"Expose primary keys","$":"true"} ]}}};
  await call('POST', `/workspaces/${ws}/datastores`, body).catch(()=>{});
}
async function publishTable(ws, store, table, layerName){ const featureType = { featureType: { name: layerName, nativeName: table, srs: "EPSG:4326" } };
  await call('POST', `/workspaces/${ws}/datastores/${store}/featuretypes`, featureType).catch(()=>{}); }
async function publishStyle(ws, name, sld){ await call('POST', `/workspaces/${ws}/styles?name=${encodeURIComponent(name)}`, sld, 'application/vnd.ogc.sld+xml').catch(()=>{}); }
async function main(){
  const ws = process.env.GS_WORKSPACE || 'tourism'; const store = process.env.GS_STORE || 'pg_api';
  await ensureWorkspace(ws); await ensurePgStore(ws, store); await publishTable(ws, store, 'places_public', 'places_public');
  const sld = `<?xml version="1.0"?><StyledLayerDescriptor version="1.0.0" xmlns="http://www.opengis.net/sld" xmlns:ogc="http://www.opengis.net/ogc">
  <NamedLayer><Name>places_public</Name><UserStyle><Title>POI Simple</Title><FeatureTypeStyle><Rule><PointSymbolizer><Graphic><Mark><WellKnownName>circle</WellKnownName>
  <Fill><CssParameter name="fill">#0099ff</CssParameter></Fill></Mark><Size>6</Size></Graphic></PointSymbolizer></Rule></FeatureTypeStyle></UserStyle></NamedLayer></StyledLayerDescriptor>`;
  await publishStyle(ws, 'poi_simple', sld); console.log('GeoServer publish completed.');
}
main().catch(e=>{ console.error(e); process.exit(1); });
