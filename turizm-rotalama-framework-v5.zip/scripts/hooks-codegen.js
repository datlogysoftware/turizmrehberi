import fs from 'node:fs';
const spec = fs.readFileSync('./openapi/openapi.yaml','utf-8');
function hasPath(p){ return spec.includes('\n  ' + p + ':'); }
let code = `// Auto-generated React Query hooks\n` +
`import { useQuery, useMutation } from '@tanstack/react-query';\n` +
`import { TourismApiClient } from './client';\n` +
`import type { Place, RouteResponse, Review, ReviewInput, FeedbackInput } from './types';\n` +
`const client = new TourismApiClient();\n`;
if (hasPath('/places')) { code += `\nexport const useListPlaces = (bbox:string, category?:string) => useQuery({ queryKey:['places',bbox,category], queryFn:()=>client.listPlaces({bbox,category}) });\n`; }
if (hasPath('/places/{id}')) { code += `\nexport const usePlace = (id:string) => useQuery({ queryKey:['place',id], queryFn:()=>client.getPlace(id), enabled:!!id });\n`; }
if (hasPath('/routing')) { code += `\nexport const useRoute = (mode:'walk'|'drive'|'transit', from:string, to:string) => useQuery({ queryKey:['route',mode,from,to], queryFn:()=>client.getRoute({mode,from,to}), enabled:!!from && !!to });\n`; }
if (hasPath('/reviews')) { code += `\nexport const useSubmitReview = () => useMutation({ mutationFn:(b:ReviewInput)=>client.submitReview(b) });\n`; }
if (hasPath('/feedback')) { code += `\nexport const useSubmitFeedback = () => useMutation({ mutationFn:(b:FeedbackInput)=>client.submitFeedback(b) });\n`; }
fs.writeFileSync('./packages/sdk/src/hooks.generated.ts', code);
console.log('Generated packages/sdk/src/hooks.generated.ts');
