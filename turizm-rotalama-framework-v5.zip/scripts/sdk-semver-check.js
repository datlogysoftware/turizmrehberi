import fs from 'node:fs';
const sdk = fs.readFileSync('./packages/sdk/src/version.ts','utf-8');
const m1 = sdk.match(/SDK_VERSION\s*=\s*'([0-9]+\.[0-9]+\.[0-9]+)'/);
const sdkVersion = m1 ? m1[1] : '0.0.0';
const api = fs.readFileSync('./openapi/openapi.yaml','utf-8');
const m2 = api.match(/version:\s*([0-9]+\.[0-9]+\.[0-9]+)/);
const apiVersion = m2 ? m2[1] : '0.0.0';
function parse(v){ return v.split('.').map(n=>parseInt(n,10)); }
function compatible(a,b){ const [aM,aN]=parse(a), [bM,bN]=parse(b); return aM===bM && aN<=bN; }
if (!compatible(sdkVersion, apiVersion)) {
  console.error(`SDK/API version mismatch: SDK=${sdkVersion} API=${apiVersion}`); process.exit(1);
} else { console.log(`SDK/API compatible ✓ SDK=${sdkVersion} API=${apiVersion}`); }
