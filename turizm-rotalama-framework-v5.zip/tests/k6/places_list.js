import http from 'k6/http'; import { sleep, check } from 'k6';
export const options = { vus: 20, duration: '1m' };
export default function () { const res = http.get(`${__ENV.BASE_URL}/places?bbox=28.5,36.0,33.0,41.0&category=park`);
  check(res, { 'status 200': (r) => r.status === 200 }); sleep(1); }