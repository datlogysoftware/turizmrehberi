import http from 'k6/http'; import { sleep, check } from 'k6';
export const options = { vus: 10, duration: '1m' };
export default function () { const q = `mode=walk&from=29.0,41.0&to=29.02,41.02`;
  const res = http.get(`${__ENV.BASE_URL}/routing?` + q); check(res, { 'status 200': (r) => r.status === 200 }); sleep(1); }